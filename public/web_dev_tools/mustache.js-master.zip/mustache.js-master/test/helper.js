assert = require('assert');
Mustache = require('../mustache');
