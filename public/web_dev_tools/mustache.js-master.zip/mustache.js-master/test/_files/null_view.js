({
  name: 'Joe',
  friends: null
})
